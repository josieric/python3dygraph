
from setuptools import setup

setup(name='dygraph',
      version='0.1',
      description='Use dygraph.js',
      author='ToRicSoft Circus',
      author_email='eric.josien@free.fr',
      license='MIT',
      packages=['dygraph'],
      include_package_data = True,
      zip_safe=False)

