Cf test.py
OR
https://github.com/josieric/python3dygraph/
